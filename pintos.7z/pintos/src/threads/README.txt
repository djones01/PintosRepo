Added line in tests.c for alarm mega in tests struct
Added test name in Make.tests
Added line for alarm-mega in Rubric.alarm
Added new extern in tests.h
Created new function definition for test_alarm_mega in alarm-wait.c
Created alarm-mega.ck from alarm-multiple.ck and changed the check_alarm argument to 70 (this is probably unncessessary)
